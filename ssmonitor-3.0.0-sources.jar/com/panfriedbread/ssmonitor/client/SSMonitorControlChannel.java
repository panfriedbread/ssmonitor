package com.panfriedbread.ssmonitor.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

public final class SSMonitorControlChannel {
    private SSMonitorControlChannel() {
    }

    public static void register(TelemetryManager telemetry) {
        PayloadTypeRegistry.playS2C().register(SSMonitorControlPayload.ID, SSMonitorControlPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SSMonitorControlPayload.ID, SSMonitorControlPayload.CODEC);
        ClientPlayNetworking.registerGlobalReceiver(SSMonitorControlPayload.ID,
                (payload, context) -> telemetry.handleControlMessage(payload.json(), context.client()));
    }

    public static void sendClientReady(ClientSession session) {
        if (session == null) {
            return;
        }
        String message = "{\"type\":\"CLIENT_READY\",\"protocol\":" + session.protocol()
                + ",\"session_id\":\"" + JsonUtil.escape(session.sessionId()) + "\"}";
        try {
            ClientPlayNetworking.send(new SSMonitorControlPayload(message));
        } catch (IllegalStateException ignored) {
            // The connection may close between receiving SESSION_INIT and this acknowledgement.
        }
    }
}
