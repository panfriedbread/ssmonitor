package com.panfriedbread.ssmonitor.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Inventories DLLs mapped into this JVM. This is deliberately observation-only:
 * a module that appears after the baseline is a review signal, not proof of an
 * injection or malware.
 */
public final class NativeModuleScanner {
    private static final int MAX_MODULES = 512;
    private static final long COMMAND_TIMEOUT_SECONDS = 20L;

    private final Map<String, HashCacheEntry> hashCache = new HashMap<>();
    private final Map<String, Path> currentModulePaths = new HashMap<>();
    private Set<String> previousModules = Set.of();
    private boolean baselineCreated;
    private long lastDefenderScan;

    public ScanResult scan(SSMonitorConfig config) {
        if (!isWindows()) {
            return new ScanResult("UNSUPPORTED_PLATFORM", List.of(), List.of(), false, "NOT_AVAILABLE");
        }

        List<NativeModuleSnapshot> modules;
        try {
            modules = collectModules();
        } catch (Exception exception) {
            return new ScanResult("ENUMERATION_FAILED", List.of(), List.of(), false,
                    safeError(exception));
        }

        Set<String> current = new HashSet<>();
        List<String> newlyLoaded = new ArrayList<>();
        for (NativeModuleSnapshot module : modules) {
            current.add(module.pathHash());
            if (baselineCreated && !previousModules.contains(module.pathHash())) {
                newlyLoaded.add(module.pathHash());
            }
        }
        newlyLoaded.sort(String::compareTo);
        previousModules = Set.copyOf(current);
        baselineCreated = true;

        boolean defenderRequested = false;
        String defenderStatus = "DISABLED";
        long now = System.currentTimeMillis();
        if (config.scanNativeModulesWithDefender()) {
            if (now - lastDefenderScan >= config.getNativeModuleScanSeconds() * 1_000L) {
                defenderStatus = requestDefenderScan(modules);
                lastDefenderScan = now;
                defenderRequested = defenderStatus.startsWith("REQUESTED");
            } else {
                defenderStatus = "RATE_LIMITED";
            }
        }

        return new ScanResult("OK", List.copyOf(modules), List.copyOf(newlyLoaded), defenderRequested,
                defenderStatus);
    }

    private List<NativeModuleSnapshot> collectModules() throws Exception {
        String script = "& { $ErrorActionPreference='Stop'; $p=Get-Process -Id ([int]$args[0]); "
                + "$items=foreach($m in $p.Modules){ if($m.FileName -and $m.FileName.EndsWith('.dll',[System.StringComparison]::OrdinalIgnoreCase)){ "
                + "$s=Get-AuthenticodeSignature -LiteralPath $m.FileName; [pscustomobject]@{path=$m.FileName;name=$m.ModuleName;"
                + "base_address=('0x{0:X}' -f $m.BaseAddress.ToInt64());size=[int64]$m.ModuleMemorySize;signature=$s.Status.ToString();"
                + "signer=$(if($s.SignerCertificate){$s.SignerCertificate.Subject}else{''})} } }; @($items)|ConvertTo-Json -Compress -Depth 3 }";
        Process process = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script,
                Long.toString(ProcessHandle.current().pid())).redirectErrorStream(true).start();
        boolean complete = process.waitFor(COMMAND_TIMEOUT_SECONDS, TimeUnit.SECONDS);
        if (!complete) {
            process.destroyForcibly();
            throw new IllegalStateException("enumeration_timeout");
        }
        String output;
        try (InputStream input = process.getInputStream()) {
            output = new String(input.readAllBytes(), StandardCharsets.UTF_8).trim();
        }
        if (process.exitValue() != 0) {
            throw new IllegalStateException("powershell_exit_" + process.exitValue());
        }
        JsonElement parsed = JsonParser.parseString(output.isBlank() ? "[]" : output);
        JsonArray array = parsed.isJsonArray() ? parsed.getAsJsonArray() : singleElementArray(parsed);
        List<NativeModuleSnapshot> modules = new ArrayList<>();
        currentModulePaths.clear();
        for (JsonElement element : array) {
            if (!element.isJsonObject() || modules.size() >= MAX_MODULES) {
                continue;
            }
            JsonObject item = element.getAsJsonObject();
            String rawPath = string(item, "path");
            if (rawPath.isBlank()) {
                continue;
            }
            Path path;
            try {
                path = Path.of(rawPath).toAbsolutePath().normalize();
            } catch (Exception ignored) {
                continue;
            }
            long size = size(path);
            long modified = modified(path);
            String pathHash = JsonUtil.sha256(path.toString().getBytes(StandardCharsets.UTF_8));
            currentModulePaths.put(pathHash, path);
            modules.add(new NativeModuleSnapshot(
                    pathHash,
                    string(item, "name"), string(item, "base_address"), size, hash(path, size, modified),
                    string(item, "signature"), string(item, "signer"), trustedLocation(path)));
        }
        modules.sort(Comparator.comparing(NativeModuleSnapshot::pathHash));
        return modules;
    }

    private String requestDefenderScan(List<NativeModuleSnapshot> modules) {
        // Defender's cmdlet starts a local custom scan. It does not provide a trustworthy
        // per-file verdict, so the result is reported only as a request status.
        if (modules.isEmpty()) {
            return "NO_MODULES";
        }
        try {
            String script = "& { $ErrorActionPreference='Stop'; foreach($path in $args){ Start-MpScan -ScanType CustomScan -ScanPath $path -ErrorAction Stop }; 'REQUESTED' }";
            List<String> command = new ArrayList<>(List.of("powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script));
            for (NativeModuleSnapshot module : modules) {
                Path path = currentModulePaths.get(module.pathHash());
                if (path != null && Files.isRegularFile(path)) {
                    // Paths stay on the client and are never added to the report.
                    command.add(path.toString());
                }
            }
            if (command.size() == 5) {
                return "NO_READABLE_MODULES";
            }
            Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
            boolean complete = process.waitFor(10, TimeUnit.MINUTES);
            if (!complete) {
                process.destroyForcibly();
                return "REQUESTED_TIMEOUT";
            }
            return process.exitValue() == 0 ? "REQUESTED" : "FAILED_EXIT_" + process.exitValue();
        } catch (Exception exception) {
            return "FAILED:" + safeError(exception);
        }
    }

    private String hash(Path path, long size, long modified) {
        String key = path.toString();
        HashCacheEntry cached = hashCache.get(key);
        if (cached != null && cached.size() == size && cached.modified() == modified) {
            return cached.sha256();
        }
        String hash = sha256(path);
        hashCache.put(key, new HashCacheEntry(size, modified, hash));
        return hash;
    }

    private static String sha256(Path path) {
        try (InputStream input = Files.newInputStream(path)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[16_384];
            for (int read; (read = input.read(buffer)) != -1; ) {
                digest.update(buffer, 0, read);
            }
            return java.util.HexFormat.of().formatHex(digest.digest());
        } catch (Exception ignored) {
            return "unavailable";
        }
    }

    private static long size(Path path) {
        try {
            return Files.size(path);
        } catch (Exception ignored) {
            return -1L;
        }
    }

    private static long modified(Path path) {
        try {
            return Files.getLastModifiedTime(path).toMillis();
        } catch (Exception ignored) {
            return -1L;
        }
    }

    private static boolean trustedLocation(Path path) {
        String value = path.toString().toLowerCase(Locale.ROOT);
        String systemRoot = System.getenv("SystemRoot");
        if (systemRoot != null && value.startsWith(Path.of(systemRoot).toAbsolutePath().normalize().toString().toLowerCase(Locale.ROOT))) {
            return true;
        }
        String javaHome = System.getProperty("java.home", "");
        return !javaHome.isBlank() && value.startsWith(Path.of(javaHome).toAbsolutePath().normalize().toString().toLowerCase(Locale.ROOT));
    }

    private static JsonArray singleElementArray(JsonElement value) {
        JsonArray array = new JsonArray();
        array.add(value);
        return array;
    }

    private static String string(JsonObject object, String key) {
        JsonElement value = object.get(key);
        return value != null && value.isJsonPrimitive() ? value.getAsString() : "";
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private static String safeError(Exception exception) {
        return exception.getClass().getSimpleName();
    }

    public record ScanResult(String status, List<NativeModuleSnapshot> modules, List<String> newlyLoadedPathHashes,
                             boolean defenderScanRequested, String defenderScanStatus) {
    }

    public record NativeModuleSnapshot(String pathHash, String name, String baseAddress, long size, String sha256,
                                       String signatureStatus, String signer, boolean trustedLocation) {
    }

    private record HashCacheEntry(long size, long modified, String sha256) {
    }
}
