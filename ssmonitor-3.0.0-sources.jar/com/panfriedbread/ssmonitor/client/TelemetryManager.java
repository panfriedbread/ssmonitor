package com.panfriedbread.ssmonitor.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.class_310;
import net.minecraft.class_437;

public final class TelemetryManager {
    private final SSMonitorConfig config;
    private final AtomicLong sequence;
    private final InputTracker inputTracker;
    private final IntegrityScanner integrityScanner;
    private final NativeModuleScanner nativeModuleScanner;

    private final HttpClient httpClient =
            HttpClient.newBuilder()
                    .connectTimeout(
                            Duration.ofSeconds(10)
                    )
                    .build();

    private final ExecutorService worker =
            Executors.newSingleThreadExecutor(
                    runnable -> {
                        Thread thread =
                                new Thread(
                                        runnable,
                                        "ssmonitor-http"
                                );

                        thread.setDaemon(true);

                        return thread;
                    }
            );

    private final ConcurrentLinkedDeque<QueuedReport> queue =
            new ConcurrentLinkedDeque<>();
    private final AtomicBoolean drainScheduled =
            new AtomicBoolean();
    private final AtomicBoolean fullReportScheduled =
            new AtomicBoolean();
    private final Deque<InputTracker.InputEvent> pendingInputEvents =
            new ArrayDeque<>();

    private volatile boolean running;
    private volatile long consecutiveFailures;
    private volatile String lastFailure = "";
    private volatile long lastSuccessfulDelivery;
    private volatile String lastScreen = "";
    private volatile String currentServer = "";
    private volatile long lastSelfTest = 0L;
    private volatile ClientSession session;
    private long lastInputFlush;
    private volatile long nextAttemptAt;

    public TelemetryManager(
            SSMonitorConfig config,
            AtomicLong sequence,
            InputTracker inputTracker
    ) {
        this.config = config;
        this.sequence = sequence;
        this.inputTracker = inputTracker;
        this.integrityScanner =
                new IntegrityScanner(config);
        this.nativeModuleScanner =
                new NativeModuleScanner();
    }

    public void start() {
        running = true;

        if (lastSelfTest == 0L) {
            sendEvent(
                    "SELF_TEST",
                    "{\"state\":\"STARTED\"}"
            );
        }
    }

    public void stop() {
        running = false;
        queue.clear();
        pendingInputEvents.clear();
    }

    public boolean isRunning() {
        return running;
    }

    public int getQueueSize() {
        return queue.size();
    }

    public long getConsecutiveFailures() {
        return consecutiveFailures;
    }

    public String getLastFailure() {
        return lastFailure.isBlank()
                ? "none"
                : lastFailure;
    }

    public String getEndpointStatus() {
        ClientSession currentSession = session;

        if (currentSession == null || !currentSession.valid()) {
            return "no_session";
        }

        String endpoint = !currentSession.endpoint().isBlank()
                ? currentSession.endpoint()
                : config.getServerUrl();

        if (endpoint.isBlank()) {
            return "missing";
        }

        try {
            URI uri = URI.create(endpoint);
            String host = uri.getHost();

            if ((!("http".equalsIgnoreCase(uri.getScheme())
                    || "https".equalsIgnoreCase(uri.getScheme()))
                    || host == null
                    || host.isBlank()
                    || "0.0.0.0".equals(host)
                    || "::".equals(host))) {
                return "invalid";
            }

            return "configured:" + uri.getAuthority();
        } catch (IllegalArgumentException ignored) {
            return "invalid";
        }
    }

    private boolean hasUsableEndpoint() {
        return getEndpointStatus().startsWith("configured:");
    }

    private String endpoint() {
        ClientSession currentSession = session;
        return currentSession == null
                ? ""
                : !currentSession.endpoint().isBlank()
                || !config.getServerUrl().isBlank()
                ? (!currentSession.endpoint().isBlank()
                        ? currentSession.endpoint()
                        : config.getServerUrl())
                : "";
    }

    public void onServerJoin(
            class_310 client
    ) {
        currentServer =
                getServerIdentity(client);

    }

    public void onServerDisconnect() {
        session = null;
        queue.clear();
        pendingInputEvents.clear();
        RawClickTracker.clear();
        currentServer = "";
    }

    public void processClickTiming() {
        if (!running || session == null) {
            return;
        }
        List<Long> intervals = RawClickTracker.intervalsForReport();
        if (intervals.isEmpty()) {
            return;
        }
        StringBuilder body = new StringBuilder("{\"intervals_us\":[");
        for (int index = 0; index < intervals.size(); index++) {
            if (index > 0) {
                body.append(',');
            }
            body.append(intervals.get(index));
        }
        body.append("]}");
        sendEvent("CLICK_TIMING", body.toString());
    }

    public void processInput(
            class_310 client
    ) {
        if (
                !config.reportInput()
                        || !running
                        || session == null
        ) {
            return;
        }

        List<InputTracker.InputEvent> events =
                inputTracker.update(client);

        int maxBuffered =
                config.getMaxInputEventsPerReport()
                        * 4;

        for (InputTracker.InputEvent event : events) {
            while (pendingInputEvents.size() >= maxBuffered) {
                pendingInputEvents.pollFirst();
            }

            pendingInputEvents.addLast(event);
        }

        flushPendingInputEvents();
    }

    private void flushPendingInputEvents() {
        if (pendingInputEvents.isEmpty()) {
            return;
        }

        long now = System.currentTimeMillis();

        if (now - lastInputFlush
                < config.getInputReportIntervalSeconds()
                * 1000L) {
            return;
        }

        lastInputFlush = now;

        StringBuilder array =
                new StringBuilder("[");

        boolean first = true;
        int limit = config.getMaxInputEventsPerReport();

        while (!pendingInputEvents.isEmpty()
                && limit-- > 0) {
            InputTracker.InputEvent event =
                    pendingInputEvents.pollFirst();

            if (!first) {
                array.append(',');
            }

            first = false;

            array.append('{')
                    .append("\"id\":\"")
                    .append(
                            JsonUtil.escape(
                                    event.id()
                            )
                    )
                    .append("\",")
                    .append("\"pressed\":")
                    .append(
                            event.pressed()
                    )
                    .append('}');
        }

        array.append(']');

        sendEvent(
                "INPUT_EVENT",
                "{\"events\":"
                        + array
                        + "}"
        );
    }

    public void processScreenState(
            class_310 client
    ) {
        if (
                !config.reportScreen()
                        || !running
                        || session == null
        ) {
            return;
        }

        class_437 screen =
                client.field_1755;

        String state =
                screen == null
                        ? "GAMEPLAY"
                        : screen.getClass()
                        .getName();

        if (!state.equals(lastScreen)) {
            String previous =
                    lastScreen;

            lastScreen = state;

            sendEvent(
                    "SCREEN_CHANGE",
                    "{\"previous\":\""
                            + JsonUtil.escape(previous)
                            + "\",\"current\":\""
                            + JsonUtil.escape(state)
                            + "\"}"
            );
        }
    }

    public void sendFullReport(
            class_310 client,
            String reason
    ) {
        ClientSession reportSession = session;
        if (!running || reportSession == null || !reportSession.valid()) {
            return;
        }

        String playerUuid = getPlayerUuid(client);
        if (playerUuid.isBlank() || !fullReportScheduled.compareAndSet(false, true)) {
            return;
        }
        String server = currentServer;
        worker.submit(() -> {
            try {
                if (running && session == reportSession) {
                    buildFullReport(reportSession, playerUuid, server, reason);
                }
            } finally {
                fullReportScheduled.set(false);
            }
        });
    }

    private void buildFullReport(
            ClientSession reportSession,
            String playerUuid,
            String server,
            String reason
    ) {
        IntegrityScanner.ScanResult scan =
                integrityScanner.scan();

        NativeModuleScanner.ScanResult nativeModules =
                config.reportNativeModules()
                        ? nativeModuleScanner.scan(config)
                        : new NativeModuleScanner.ScanResult(
                        "DISABLED",
                        List.of(),
                        List.of(),
                        false,
                        "DISABLED"
                );

        RuntimeSnapshot runtime =
                new RuntimeSnapshot();

        String reportId =
                UUID.randomUUID().toString();

        long reportSequence =
                sequence.incrementAndGet();

        StringBuilder json =
                new StringBuilder();

        json.append('{');

        field(
                json,
                "type",
                "FULL_REPORT"
        ).append(',');

        field(
                json,
                "version",
                SSMonitorClient.VERSION
        ).append(',');

        json.append("\"protocol\":2,");

        field(
                json,
                "session_id",
                reportSession.sessionId()
        ).append(',');

        field(
                json,
                "timestamp",
                Instant.now().toString()
        ).append(',');

        field(
                json,
                "report_id",
                reportId
        ).append(',');

        field(
                json,
                "reason",
                reason
        ).append(',');

        json.append(
                "\"sequence\":"
        ).append(
                reportSequence
        ).append(',');

        field(
                json,
                "player_uuid",
                playerUuid
        ).append(',');

        field(
                json,
                "minecraft_version",
                "1.21.11"
        ).append(',');

        field(
                json,
                "server",
                server
        ).append(',');

        json.append(
                        "\"self_integrity\":{\"sha256\":\""
                )
                .append(
                        JsonUtil.escape(
                                scan.selfHash()
                        )
                )
                .append(
                        "\",\"expected_sha256\":\""
                )
                .append(
                        JsonUtil.escape(
                                config.getExpectedSelfSha256()
                        )
                )
                .append(
                        "\",\"matches_expected\":"
                )
                .append(
                        config.getExpectedSelfSha256()
                                .isBlank()
                                || config.getExpectedSelfSha256()
                                .equalsIgnoreCase(
                                        scan.selfHash()
                                )
                )
                .append('}');

        if (config.reportMods()) {
            json.append(',')
                    .append(
                            "\"mods\":"
                    )
                    .append(
                            modsJson(
                                    scan.mods()
                            )
                    );

            json.append(',')
                    .append(
                            "\"changes\":"
                    )
                    .append(
                            changesJson(
                                    scan.changes()
                            )
                    );
        }

        if (config.reportJvm()) {
            json.append(',')
                    .append(
                            "\"jvm\":"
                    )
                    .append(
                            runtime.toJson()
                    );
        }

        json.append(',')
                .append(
                        "\"health\":"
                )
                .append(
                        healthJson()
                );

        json.append('}');

        if (!running || session != reportSession) {
            return;
        }

        if (config.reportNativeModules()) {
            json.append(',')
                    .append("\"native_module_scan\":")
                    .append(nativeModuleScanJson(nativeModules));
        }

        enqueue(
                json.toString()
        );

        for (
                IntegrityScanner.Change change :
                scan.changes()
        ) {
            sendEvent(
                    change.type(),
                    changeJson(change)
            );
        }

        long now =
                System.currentTimeMillis();

        if (
                now - lastSelfTest
                        >= config.getHeartbeatSeconds()
                        * 1000L
        ) {
            lastSelfTest = now;

            sendEvent(
                    "SELF_TEST",
                    "{\"running\":"
                            + running
                            + ",\"queue\":"
                            + queue.size()
                            + ",\"failures\":"
                            + consecutiveFailures
                            + "}"
            );
        }
    }

    public void sendEvent(
            String type,
            String body
    ) {
        if (
                !running
                        || session == null
        ) {
            return;
        }

        class_310 client = class_310.method_1551();
        String playerUuid = getPlayerUuid(client);

        if (playerUuid.isBlank()) {
            return;
        }

        StringBuilder json =
                new StringBuilder();

        json.append('{');

        field(
                json,
                "type",
                type
        ).append(',');

        field(
                json,
                "version",
                SSMonitorClient.VERSION
        ).append(',');

        json.append("\"protocol\":2,");

        field(
                json,
                "session_id",
                session.sessionId()
        ).append(',');

        field(
                json,
                "report_id",
                UUID.randomUUID().toString()
        ).append(',');

        field(
                json,
                "player_uuid",
                playerUuid
        ).append(',');

        field(
                json,
                "timestamp",
                Instant.now().toString()
        ).append(',');

        json.append(
                "\"sequence\":"
        ).append(
                sequence.incrementAndGet()
        );

        if (
                body != null
                        && !body.isBlank()
        ) {
            if (body.startsWith("{")) {
                json.append(',')
                        .append(
                                body.substring(
                                        1
                                )
                        );
            }
        }

        enqueue(
                json.toString()
        );
    }

    private void enqueue(
            String payload
    ) {
        ClientSession currentSession = session;

        if (currentSession == null || !currentSession.valid()) {
            return;
        }

        String target = endpoint();

        if (!hasUsableEndpoint()) {
            if (!"ENDPOINT_NOT_CONFIGURED".equals(lastFailure)
                    && !"INVALID_ENDPOINT".equals(lastFailure)) {
                consecutiveFailures++;
                lastFailure = target.isBlank()
                        ? "ENDPOINT_NOT_CONFIGURED"
                        : "INVALID_ENDPOINT";
            }
            return;
        }

        boolean challenge = "CHALLENGE_RESPONSE".equals(typeFrom(payload));

        if (!challenge && System.currentTimeMillis() < nextAttemptAt) {
            return;
        }

        while (
                queue.size()
                        >= config.getMaxQueue()
        ) {
            queue.poll();
        }

        QueuedReport report = new QueuedReport(
                payload,
                target,
                currentSession.token()
        );

        if (challenge) {
            queue.offerFirst(report);
        } else {
            queue.offerLast(report);
        }

        scheduleDrain();
    }

    private void drain() {
        boolean failed = false;

        if (!running) {
            drainScheduled.set(false);
            return;
        }

        try {
            while (true) {
                QueuedReport report =
                        queue.peek();

                if (report == null) {
                    return;
                }

                HttpRequest request =
                        HttpRequest.newBuilder(
                                        URI.create(
                                                report.target()
                                        )
                                )
                                .timeout(
                                        Duration.ofSeconds(10)
                                )
                                .header(
                                        "Content-Type",
                                        "application/json"
                                )
                                .header(
                                        "User-Agent",
                                        "SSMonitor/3.0 Minecraft/1.21.11"
                                )
                                .header(
                                        "Authorization",
                                        "Bearer " + report.token()
                                )
                                .POST(
                                        HttpRequest
                                                .BodyPublishers
                                                .ofString(
                                                        report.payload(),
                                                        StandardCharsets.UTF_8
                                                )
                                )
                                .build();

                HttpResponse<String> response;

                try {
                    response = httpClient.send(
                                request,
                                HttpResponse.BodyHandlers.ofString(
                                        StandardCharsets.UTF_8
                                )
                        );
                } catch (Exception exception) {
                    consecutiveFailures++;
                    lastFailure = describeFailure(exception);
                    queue.poll();
                    discardStaleTelemetry();
                    scheduleRetryBackoff();
                    failed = true;
                    return;
                }

                int status =
                        response.statusCode();

                if (status >= 200 && status < 300) {
                    queue.poll();
                    consecutiveFailures = 0;
                    lastFailure = "";
                    nextAttemptAt = 0L;
                    lastSuccessfulDelivery =
                            System.currentTimeMillis();
                    continue;
                }

                consecutiveFailures++;
                lastFailure =
                        "HTTP_" + status;
                queue.poll();
                discardStaleTelemetry();
                scheduleRetryBackoff();
                failed = true;
                return;
            }
        } finally {
            drainScheduled.set(false);

            if (!failed && !queue.isEmpty()
                    && running) {
                scheduleDrain();
            }
        }
    }

    private void scheduleDrain() {
        if (drainScheduled.compareAndSet(false, true)) {
            worker.submit(this::drain);
        }
    }

    private static String typeFrom(String payload) {
        try {
            return string(JsonParser.parseString(payload).getAsJsonObject(), "type");
        } catch (Exception ignored) {
            return "";
        }
    }

    private void discardStaleTelemetry() {
        queue.removeIf(report -> !"CHALLENGE_RESPONSE".equals(typeFrom(report.payload())));
    }

    private void scheduleRetryBackoff() {
        long seconds = Math.min(30L, 1L << Math.min(5L, consecutiveFailures));
        nextAttemptAt = System.currentTimeMillis() + seconds * 1000L;
    }

    private static String describeFailure(Exception exception) {
        Throwable current = exception;

        while (current.getCause() != null) {
            current = current.getCause();
        }

        if (current instanceof ConnectException) {
            return "CONNECT_REFUSED";
        }

        if (current instanceof UnknownHostException) {
            return "UNKNOWN_HOST";
        }

        if (current instanceof SocketTimeoutException
                || exception instanceof java.net.http.HttpTimeoutException) {
            return "TIMEOUT";
        }

        String message = current.getMessage();
        return current.getClass().getSimpleName()
                + (message == null || message.isBlank()
                ? ""
                : ":" + message.replace('\n', ' ').replace('\r', ' '));
    }

    private String modsJson(
            Map<String, IntegrityScanner.ModSnapshot> mods
    ) {
        List<String> ids =
                new ArrayList<>(
                        mods.keySet()
                );

        ids.sort(
                String::compareTo
        );

        StringBuilder json =
                new StringBuilder("[");

        boolean first = true;

        for (String id : ids) {
            if (!first) {
                json.append(',');
            }

            first = false;

            IntegrityScanner.ModSnapshot mod =
                    mods.get(id);

            json.append('{');

            field(
                    json,
                    "id",
                    mod.id()
            ).append(',');

            field(
                    json,
                    "name",
                    mod.name()
            ).append(',');

            field(
                    json,
                    "version",
                    mod.version()
            ).append(',');

            field(
                    json,
                    "origin_kind",
                    mod.originKind()
            ).append(',');

            field(
                    json,
                    "parent_id",
                    mod.parentId()
            ).append(',');

            field(
                    json,
                    "parent_location",
                    mod.parentLocation()
            ).append(',');

            field(
                    json,
                    "containing_mod",
                    mod.containingMod()
            ).append(',');

            json.append(
                    "\"contained_mods\":"
            ).append(
                    JsonUtil.stringArray(
                            mod.containedMods()
                    )
            );

            if (config.reportFileHashes()) {
                json.append(',')
                        .append(
                                "\"files\":"
                        )
                        .append(
                                filesJson(
                                        mod.files()
                                )
                        );
            }

            json.append('}');
        }

        return json.append(']').toString();
    }

    private String filesJson(
            List<IntegrityScanner.FileSnapshot> files
    ) {
        StringBuilder json =
                new StringBuilder("[");

        boolean first = true;

        for (
                IntegrityScanner.FileSnapshot file :
                files
        ) {
            if (!first) {
                json.append(',');
            }

            first = false;

            json.append('{');

            field(
                    json,
                    "path_hash",
                    file.pathHash()
            ).append(',');

            json.append(
                    "\"regular\":"
            ).append(
                    file.regular()
            ).append(',');

            json.append(
                    "\"size\":"
            ).append(
                    file.size()
            ).append(',');

            json.append(
                    "\"modified\":"
            ).append(
                    file.modified()
            ).append(',');

            field(
                    json,
                    "sha256",
                    file.sha256()
            );

            json.append('}');
        }

        return json.append(']').toString();
    }

    private String changesJson(
            List<IntegrityScanner.Change> changes
    ) {
        StringBuilder json =
                new StringBuilder("[");

        boolean first = true;

        for (
                IntegrityScanner.Change change :
                changes
        ) {
            if (!first) {
                json.append(',');
            }

            first = false;

            json.append(
                    changeJson(
                            change
                    )
            );
        }

        return json.append(']').toString();
    }

    private String changeJson(
            IntegrityScanner.Change change
    ) {
        return "{"
                + "\"type\":\""
                + JsonUtil.escape(
                change.type()
        )
                + "\","
                + "\"mod_id\":\""
                + JsonUtil.escape(
                change.modId()
        )
                + "\","
                + "\"before\":\""
                + JsonUtil.escape(
                change.before()
        )
                + "\","
                + "\"after\":\""
                + JsonUtil.escape(
                change.after()
        )
                + "\""
                + "}";
    }

    private String healthJson() {
        return "{"
                + "\"running\":"
                + running
                + ","
                + "\"queue\":"
                + queue.size()
                + ","
                + "\"consecutive_failures\":"
                + consecutiveFailures
                + ","
                + "\"last_failure\":\""
                + JsonUtil.escape(
                lastFailure
        )
                + "\","
                + "\"last_successful_delivery\":"
                + lastSuccessfulDelivery
                + "}";
    }

    private String getPlayerUuid(
            class_310 client
    ) {
        if (client.field_1724 == null) {
            return "";
        }

        return client.field_1724
                .method_5845();
    }

    private String getServerIdentity(
            class_310 client
    ) {
        if (
                client.method_1558()
                        == null
        ) {
            return "unknown";
        }

        String name =
                client.method_1558()
                        .field_3752;

        String address =
                client.method_1558()
                        .field_3761;

        String addressHash =
                JsonUtil.sha256(
                        address.getBytes(
                                StandardCharsets.UTF_8
                        )
                );

        return name
                + "|"
                + addressHash;
    }

    private static StringBuilder field(
            StringBuilder builder,
            String key,
            String value
    ) {
        builder.append('"')
                .append(
                        JsonUtil.escape(
                                key
                        )
                )
                .append("\":\"")
                .append(
                        JsonUtil.escape(
                                value == null
                                        ? ""
                                        : value
                        )
                )
                .append('"');

        return builder;
    }

    private String nativeModuleScanJson(
            NativeModuleScanner.ScanResult scan
    ) {
        StringBuilder json = new StringBuilder("{");
        field(json, "status", scan.status()).append(',');
        json.append("\"defender_scan_requested\":")
                .append(scan.defenderScanRequested())
                .append(',');
        field(json, "defender_scan_status", scan.defenderScanStatus()).append(',');
        json.append("\"newly_loaded_path_hashes\":")
                .append(JsonUtil.stringArray(scan.newlyLoadedPathHashes()))
                .append(',');
        json.append("\"modules\":[");
        boolean first = true;
        for (NativeModuleScanner.NativeModuleSnapshot module : scan.modules()) {
            if (!first) {
                json.append(',');
            }
            first = false;
            json.append('{');
            field(json, "path_hash", module.pathHash()).append(',');
            field(json, "name", module.name()).append(',');
            field(json, "base_address", module.baseAddress()).append(',');
            json.append("\"size\":").append(module.size()).append(',');
            field(json, "sha256", module.sha256()).append(',');
            field(json, "signature_status", module.signatureStatus()).append(',');
            field(json, "signer", module.signer()).append(',');
            json.append("\"trusted_location\":").append(module.trustedLocation());
            json.append('}');
        }
        return json.append("]}").toString();
    }

    public void handleControlMessage(
            String message,
            class_310 client
    ) {
        try {
            JsonObject control =
                    JsonParser.parseString(message)
                            .getAsJsonObject();

            String type = string(control, "type");

            if ("SESSION_INIT".equals(type)) {
                ClientSession next = new ClientSession(
                        integer(control, "protocol"),
                        string(control, "session_id"),
                        string(control, "token"),
                        string(control, "endpoint")
                );

                if (!next.valid()) {
                    lastFailure = "INVALID_SESSION_INIT";
                    SSMonitorClient.sendMessage("Ignored an invalid SS Monitor session packet from the server.");
                    return;
                }

                session = next;
                running = true;
                queue.clear();
                RawClickTracker.clear();
                lastFailure = "none";
                SSMonitorControlChannel.sendClientReady(next);
                SSMonitorClient.sendMessage("Server monitoring session received.");

                if (!hasUsableEndpoint()) {
                    lastFailure = getEndpointStatus().equals("missing")
                            ? "ENDPOINT_NOT_CONFIGURED"
                            : "INVALID_ENDPOINT";
                    SSMonitorClient.sendMessage(
                            "Server session received, but its telemetry endpoint is unavailable."
                    );
                    return;
                }

                sendEvent("HELLO", "{}");
                sendEvent(
                        "SERVER_JOIN",
                        "{\"server\":\""
                                + JsonUtil.escape(currentServer)
                                + "\"}"
                );
                sendFullReport(client, "SESSION_INIT");
                return;
            }

            ClientSession currentSession = session;

            if (currentSession == null
                    || !currentSession.sessionId().equals(
                    string(control, "session_id")
            )) {
                return;
            }

            if ("REQUEST_FULL_REPORT".equals(type)) {
                sendFullReport(
                        client,
                        string(control, "reason")
                );
            } else if ("CHALLENGE".equals(type)) {
                sendEvent(
                        "CHALLENGE_RESPONSE",
                        "{\"challenge_id\":\""
                                + JsonUtil.escape(
                                string(control, "challenge_id")
                        )
                                + "\",\"nonce\":\""
                                + JsonUtil.escape(
                                string(control, "nonce")
                        )
                                + "\"}"
                );
            } else if ("AUTOMATED_CLICKING_WARNING".equals(type)) {
                SSMonitorClient.sendWarning(
                        "Your click timing triggered an automated-clicking warning. "
                                + "Stop using automated clicking; continued patterns may be reviewed by staff."
                );
            } else if ("MONITORING_DISABLED".equals(type)) {
                running = false;
                session = null;
                queue.clear();
                pendingInputEvents.clear();
                SSMonitorClient.sendMessage(
                        "Server monitoring was disabled for this session."
                );
            }
        } catch (Exception exception) {
            lastFailure = "CONTROL_" + exception.getClass().getSimpleName();
            SSMonitorClient.sendMessage("Could not read an SS Monitor control packet: "
                    + exception.getClass().getSimpleName());
        }
    }

    public boolean hasSession() {
        ClientSession currentSession = session;
        return currentSession != null && currentSession.valid();
    }

    private static String string(
            JsonObject object,
            String key
    ) {
        return object.has(key)
                && object.get(key).isJsonPrimitive()
                && object.get(key).getAsJsonPrimitive().isString()
                ? object.get(key).getAsString()
                : "";
    }

    private static int integer(
            JsonObject object,
            String key
    ) {
        try {
            return object.has(key)
                    && object.get(key).isJsonPrimitive()
                    && object.get(key).getAsJsonPrimitive().isNumber()
                    ? object.get(key).getAsInt()
                    : -1;
        } catch (Exception ignored) {
            return -1;
        }
    }

    private record QueuedReport(
            String payload,
            String target,
            String token
    ) {
    }
}
