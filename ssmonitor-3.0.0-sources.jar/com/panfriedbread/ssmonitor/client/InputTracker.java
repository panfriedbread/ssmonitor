package com.panfriedbread.ssmonitor.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_304;
import net.minecraft.class_310;

public final class InputTracker {
    private final Map<String, Boolean> previousStates =
            new HashMap<>();

    public List<InputEvent> update(class_310 client) {
        List<InputEvent> events =
                new ArrayList<>();

        if (client.field_1690 == null) {
            return events;
        }

        for (class_304 keyBinding : client.field_1690.field_1839) {
            String id = keyBinding.method_1431();

            if (isExcluded(id)) {
                continue;
            }

            boolean current =
                    keyBinding.method_1434();

            boolean previous =
                    previousStates.getOrDefault(
                            id,
                            false
                    );

            if (current != previous) {
                events.add(
                        new InputEvent(
                                id,
                                current
                        )
                );

                previousStates.put(
                        id,
                        current
                );
            }
        }

        return events;
    }

    private boolean isExcluded(String id) {
        String normalized =
                id.toLowerCase();

        return normalized.equals("key.chat")
                || normalized.equals("key.command")
                || normalized.equals("key.socialInteractions")
                || normalized.contains("chat")
                || normalized.contains("command");
    }

    public record InputEvent(
            String id,
            boolean pressed
    ) {
    }
}