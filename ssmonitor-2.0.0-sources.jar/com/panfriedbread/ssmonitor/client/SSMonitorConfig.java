package com.panfriedbread.ssmonitor.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class SSMonitorConfig {
    private final Path path;
    private final Properties properties = new Properties();

    private SSMonitorConfig(Path path) {
        this.path = path;
    }

    public static SSMonitorConfig load(Path path) {
        SSMonitorConfig config = new SSMonitorConfig(path);

        try {
            Files.createDirectories(path.getParent());

            if (Files.exists(path)) {
                try (InputStream input = Files.newInputStream(path)) {
                    config.properties.load(input);
                }
            }
        } catch (IOException ignored) {
        }

        config.properties.putIfAbsent("heartbeat_seconds", "30");
        config.properties.putIfAbsent("scan_seconds", "30");
        config.properties.putIfAbsent("server_url", "");
        config.properties.putIfAbsent("expected_self_sha256", "");
        config.properties.putIfAbsent("report_mods", "true");
        config.properties.putIfAbsent("report_file_hashes", "true");
        config.properties.putIfAbsent("file_hash_refresh_seconds", "300");
        config.properties.putIfAbsent("report_jvm", "true");
        config.properties.putIfAbsent("report_input", "true");
        config.properties.putIfAbsent("report_screen", "true");
        config.properties.putIfAbsent("max_queue", "100");
        config.properties.putIfAbsent("input_sample_ticks", "1");
        config.properties.putIfAbsent("input_report_interval_seconds", "1");
        config.properties.putIfAbsent("max_input_events_per_report", "64");

        config.save();

        return config;
    }

    public int getHeartbeatSeconds() {
        return getInt(
                "heartbeat_seconds",
                30,
                5,
                3600
        );
    }

    public int getScanSeconds() {
        return getInt(
                "scan_seconds",
                30,
                5,
                3600
        );
    }

    public String getServerUrl() {
        return properties
                .getProperty("server_url", "")
                .trim();
    }

    public String getExpectedSelfSha256() {
        return properties
                .getProperty(
                        "expected_self_sha256",
                        ""
                )
                .trim()
                .toLowerCase();
    }

    public boolean reportMods() {
        return Boolean.parseBoolean(
                properties.getProperty(
                        "report_mods",
                        "true"
                )
        );
    }

    public boolean reportFileHashes() {
        return Boolean.parseBoolean(
                properties.getProperty(
                        "report_file_hashes",
                        "true"
                )
        );
    }

    public int getFileHashRefreshSeconds() {
        return getInt(
                "file_hash_refresh_seconds",
                300,
                30,
                3600
        );
    }

    public boolean reportJvm() {
        return Boolean.parseBoolean(
                properties.getProperty(
                        "report_jvm",
                        "true"
                )
        );
    }

    public boolean reportInput() {
        return Boolean.parseBoolean(
                properties.getProperty(
                        "report_input",
                        "true"
                )
        );
    }

    public boolean reportScreen() {
        return Boolean.parseBoolean(
                properties.getProperty(
                        "report_screen",
                        "true"
                )
        );
    }

    public int getMaxQueue() {
        return getInt(
                "max_queue",
                100,
                1,
                1000
        );
    }

    public int getInputSampleTicks() {
        return getInt(
                "input_sample_ticks",
                1,
                1,
                20
        );
    }

    public int getInputReportIntervalSeconds() {
        return getInt(
                "input_report_interval_seconds",
                1,
                1,
                60
        );
    }

    public int getMaxInputEventsPerReport() {
        return getInt(
                "max_input_events_per_report",
                64,
                1,
                256
        );
    }

    public void save() {
        try {
            Files.createDirectories(path.getParent());

            try (OutputStream output = Files.newOutputStream(path)) {
                properties.store(
                        output,
                        "SS Monitor V2 configuration"
                );
            }
        } catch (IOException ignored) {
        }
    }

    private int getInt(
            String key,
            int fallback,
            int min,
            int max
    ) {
        try {
            int value = Integer.parseInt(
                    properties.getProperty(
                            key,
                            Integer.toString(fallback)
                    )
            );

            return Math.max(
                    min,
                    Math.min(max, value)
            );
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }
}
